# Generalization_Bound_Toolbox

Tools related to computing generlization error bounds for machine-learning applications


# Installation

For now, this will not be placed on PyPi. So the following should be performed to manually install. 

The package requirements are listed in the requirements.txt file. The exact versions are probably not necessary.

First, from the same directory as this README, build the sdist and wheel using the following command.

    python -m build

Then install the wheel (*** indicates text that is version and user specific)

    pip install dist/gbtoolbox-***.whl

Build and install the c files

    cd src/gbtoolbox
    make && make install

Update your ld_library_path environment variable

    export LD_LIBRARY_PATH=/usr/local/lib/gbtoolbox/

You may want to add the previous export statement to your ~/.bashrc file, otherwise the change is only for the currently open session. 

(Does the .bashrc change work for notebooks started from window?)



Copy the resultant libraries to a known location and set environment variable. I see that I should use /usr/local/lib instead of /usr/lib. The former is for locally-installed libraries the latter is for distribution libraries or non-locally installed. use `man hier` to see fs hierarchy.
    
    sudo mkdir /usr/local/lib/gbtoolbox
    sudo cp lib* /usr/local/lib/gbtoolbox


I've added the above to the Makefile, so make install will can be used.
Q1: is the last statement needed? Yes, the path is NOT searched recursively.
Q2: The export statement is not permanent. What is the standard way of making it permanent? I have in the past edited the .bashrc file and that seems to be correct.
Q3: What is a good way of automatically updating the bashrc file? Not going to do that.




